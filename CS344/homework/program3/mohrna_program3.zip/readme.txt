Run "gcc smallsh.c -o smallsh"
