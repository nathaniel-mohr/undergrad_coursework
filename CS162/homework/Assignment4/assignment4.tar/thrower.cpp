#include "thrower.h"

Thrower::Thrower(){
	food_cost = 4;
	damage = 1;
	armor = 1;
}

string Thrower::get_name(){
	return "THROWER";
}
