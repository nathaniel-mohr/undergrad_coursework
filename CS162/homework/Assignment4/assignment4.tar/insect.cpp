#include "insect.h"

int Insect::get_armor() const{return armor;}

void Insect::set_armor(int a){armor = a;}
