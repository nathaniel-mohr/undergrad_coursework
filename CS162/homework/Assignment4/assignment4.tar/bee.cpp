#include "bee.h"

Bee::Bee(){
	armor = 3;
	damage = 1;
}

string Bee::get_name(){
	return "BEE";
}
