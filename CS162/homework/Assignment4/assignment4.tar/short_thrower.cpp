#include "short_thrower.h"

Short_Thrower::Short_Thrower(){
	food_cost = 3;
	armor = 1;
	damage = 1;
}

string Short_Thrower::get_name(){
	return "SHORT THROWER";
}
