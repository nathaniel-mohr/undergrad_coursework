#ifndef SHORT_THROWER_H
#define SHORT_THROWER_H

#include "ant.h"

class Short_Thrower: public Ant{
	public:
		Short_Thrower();
		virtual string get_name();
};

#endif
