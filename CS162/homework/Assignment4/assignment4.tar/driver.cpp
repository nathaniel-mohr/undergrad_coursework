#include "game.h"
int main(){
	Game g;
	g.play_game();
}
