#include "fire.h"

Fire::Fire(){
	food_cost = 4;
	armor = 1;
	damage = 1;
}

string Fire::get_name(){
	return "FIRE";
}
