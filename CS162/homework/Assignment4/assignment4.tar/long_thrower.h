#ifndef LONG_THROWER_H
#define LONG_THROWER_H

#include "ant.h"

class Long_Thrower: public Ant{
	public:
		Long_Thrower();
		virtual string get_name();
};

#endif
