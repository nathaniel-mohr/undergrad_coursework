#ifndef FIRE_H
#define FIRE_H

#include "ant.h"

class Fire: public Ant{
	public:
		Fire();
		virtual string get_name();
};

#endif
