#ifndef THROWER_H
#define THROWER_H

#include "ant.h"

class Thrower: public Ant{
	public:
		Thrower();
		virtual string get_name();
};

#endif
