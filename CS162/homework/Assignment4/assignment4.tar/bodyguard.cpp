#include "bodyguard.h"

Bodyguard::Bodyguard(){
	food_cost = 4;
	armor = 2;
	damage = 1;
}

string Bodyguard::get_name(){
	return "BODYGUARD";
}
