#include "ant.h"

int Ant::get_food_cost() const{return food_cost;}
