#include "ninja.h"

Ninja::Ninja(){
	food_cost = 6;
	armor = 1;
	damage = 1;
}

string Ninja::get_name(){
	return "NINJA";
}
