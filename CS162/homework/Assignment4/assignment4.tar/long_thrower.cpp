#include "long_thrower.h"

Long_Thrower::Long_Thrower(){
	food_cost = 3;
	armor = 1;
	damage = 1;
}

string Long_Thrower::get_name(){
	return "LONG THROWER";
}
