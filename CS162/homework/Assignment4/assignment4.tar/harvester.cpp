#include "harvester.h"

Harvester::Harvester(){
	food_cost = 2;
	armor = 1;
	damage = 1;
}

string Harvester::get_name(){
	return "HARVESTER";
}
