#include "game.h"

int main(){
	srand(time(NULL));
	Game tycoon;
	tycoon.play_game();
}
