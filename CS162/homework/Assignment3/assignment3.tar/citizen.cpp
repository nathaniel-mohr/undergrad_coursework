#include "citizen.h"
Citizen::Citizen(){
	max_budget = rand() % 4500 + 500;
}
