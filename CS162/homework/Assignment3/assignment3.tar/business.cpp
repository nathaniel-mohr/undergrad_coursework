#include "business.h"

Business::Business(){
	max_budget = rand() % 8000 + 2000;
}


