#ifndef BUSINESS_H
#define BUSINESS_H

#include "tenant.h"

class Business: public Tenant{
	public:
		Business();

};

#endif
