#ifndef CITIZEN_H
#define CITIZEN_H

#include "tenant.h"

class Citizen: public Tenant{
	public:
		Citizen();
};

#endif
